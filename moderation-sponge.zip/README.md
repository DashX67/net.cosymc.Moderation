# Moderation Plugin
Basic mute/ban plugin for SpongeAPI 10 (MC 1.21.1).