
package net.cosymc.moderation;

import com.google.inject.Inject;
import net.cosymc.moderation.commands.MuteCommand;
import net.cosymc.moderation.commands.BanCommand;
import org.slf4j.Logger;
import org.spongepowered.api.Sponge;
import org.spongepowered.plugin.PluginContainer;
import org.spongepowered.plugin.builtin.jvm.Plugin;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.lifecycle.RegisterCommandEvent;
import org.spongepowered.api.event.lifecycle.StartedEngineEvent;

@Plugin("moderation")
public class ModerationPlugin {
    @Inject private Logger logger;
    @Inject private PluginContainer plugin;

    @Listener
    public void onServerStart(StartedEngineEvent<org.spongepowered.api.Server> event) {
        logger.info("Moderation plugin has started.");
    }

    @Listener
    public void onRegisterCommands(RegisterCommandEvent<org.spongepowered.api.command.manager.CommandManager> event) {
        var cmdManager = event.registrar(plugin);
        cmdManager.register(MuteCommand.spec(), "mute");
        cmdManager.register(BanCommand.spec(), "ban");
    }
}
